"use strict";

require("dotenv").config();

const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const db = new Database(path.join(__dirname, "database.db"));

db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.pragma("busy_timeout = 5000");

const CATEGORIES = [
  "General consultation",
  "Cardiology",
  "Dermatology",
  "Dental care",
  "Orthopedics",
  "Eye care",
  "Pediatrics",
  "Other"
];

const DAYS = [
  "Monday", "Tuesday", "Wednesday", "Thursday",
  "Friday", "Saturday", "Sunday"
];

// ==================================================
// 1. MIDDLEWARE
// ==================================================

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(session({
  name: "carepoint.sid",
  secret: process.env.SESSION_SECRET ||
    "carepoint-development-secret-change-this",
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 8 * 60 * 60 * 1000
  }
}));

// ==================================================
// 2. DATABASE TABLES
// ==================================================

db.exec(`
  CREATE TABLE IF NOT EXISTS patients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    phone TEXT DEFAULT '',
    password_hash TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS doctors (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    specialty TEXT NOT NULL,
    working_days TEXT NOT NULL DEFAULT
      'Monday,Tuesday,Wednesday,Thursday,Friday',
    start_time TEXT NOT NULL DEFAULT '09:00',
    end_time TEXT NOT NULL DEFAULT '17:00',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
`);

// ==================================================
// 3. DATABASE MIGRATIONS
// ==================================================

function getColumns(table) {
  return db.prepare(`PRAGMA table_info(${table})`).all();
}

function ensureColumn(table, column, definition) {
  const exists = getColumns(table).some(item => item.name === column);

  if (!exists) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
    console.log(`Migration: Added ${table}.${column}`);
  }
}

ensureColumn("patients", "phone", "TEXT DEFAULT ''");
ensureColumn("patients", "password_hash", "TEXT");
ensureColumn("patients", "created_at", "TEXT");

ensureColumn("doctors", "name", "TEXT");
ensureColumn("doctors", "username", "TEXT");
ensureColumn("doctors", "password_hash", "TEXT");
ensureColumn("doctors", "specialty", "TEXT");
ensureColumn(
  "doctors",
  "working_days",
  "TEXT DEFAULT 'Monday,Tuesday,Wednesday,Thursday,Friday'"
);
ensureColumn("doctors", "start_time", "TEXT DEFAULT '09:00'");
ensureColumn("doctors", "end_time", "TEXT DEFAULT '17:00'");
ensureColumn("doctors", "created_at", "TEXT");

function migrateAppointments() {
  let columns = getColumns("appointments");

  if (!columns.length) {
    db.exec(`
      CREATE TABLE appointments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        patient_id INTEGER NOT NULL,
        doctor_id INTEGER NOT NULL,
        appointment_date TEXT NOT NULL,
        time TEXT NOT NULL,
        reason TEXT NOT NULL DEFAULT '',
        status TEXT NOT NULL DEFAULT 'Pending',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (patient_id) REFERENCES patients(id),
        FOREIGN KEY (doctor_id) REFERENCES doctors(id)
      )
    `);

    console.log("Created appointments table.");
    return;
  }

  const names = columns.map(c => c.name);

  const hasDate = names.includes("appointment_date") ||
    names.includes("date");

  const requiredSourceColumns = [
    "patient_id",
    "doctor_id",
    "time"
  ];

  const missing = requiredSourceColumns.filter(
    column => !names.includes(column)
  );

  if (!hasDate || missing.length) {
    throw new Error(
      "Cannot safely migrate appointments table. Missing columns: " +
      [...missing, ...(hasDate ? [] : ["date/appointment_date"])].join(", ")
    );
  }

  const alreadyCorrect =
    names.includes("id") &&
    names.includes("appointment_date") &&
    !names.includes("date") &&
    names.includes("time") &&
    names.includes("patient_id") &&
    names.includes("doctor_id") &&
    names.includes("reason") &&
    names.includes("status") &&
    names.includes("created_at") &&
    columns.find(c => c.name === "appointment_date")?.notnull === 1;

  if (alreadyCorrect) return;

  const dateExpression = names.includes("appointment_date")
    ? (
        names.includes("date")
          ? "COALESCE(NULLIF(appointment_date, ''), date)"
          : "appointment_date"
      )
    : "date";

  const expression = (column, fallback) =>
    names.includes(column) ? column : fallback;

  const migrate = db.transaction(() => {
    db.exec(`
      CREATE TABLE appointments_new (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        patient_id INTEGER NOT NULL,
        doctor_id INTEGER NOT NULL,
        appointment_date TEXT NOT NULL,
        time TEXT NOT NULL,
        reason TEXT NOT NULL DEFAULT '',
        status TEXT NOT NULL DEFAULT 'Pending',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (patient_id) REFERENCES patients(id),
        FOREIGN KEY (doctor_id) REFERENCES doctors(id)
      )
    `);

    db.exec(`
      INSERT INTO appointments_new (
        id, patient_id, doctor_id, appointment_date,
        time, reason, status, created_at
      )
      SELECT
        ${expression("id", "NULL")},
        patient_id,
        doctor_id,
        ${dateExpression},
        time,
        ${expression("reason", "''")},
        ${expression("status", "'Pending'")},
        ${expression("created_at", "CURRENT_TIMESTAMP")}
      FROM appointments
      WHERE ${dateExpression} IS NOT NULL
        AND ${dateExpression} != ''
    `);

    db.exec("DROP TABLE appointments");
    db.exec("ALTER TABLE appointments_new RENAME TO appointments");
  });

  migrate();
  console.log("Appointments migration completed.");
}

migrateAppointments();

db.exec(`
  CREATE INDEX IF NOT EXISTS idx_appointments_patient
  ON appointments(patient_id);

  CREATE INDEX IF NOT EXISTS idx_appointments_doctor
  ON appointments(doctor_id);

  CREATE INDEX IF NOT EXISTS idx_appointments_date
  ON appointments(appointment_date, time);
`);

// ==================================================
// 4. HELPER FUNCTIONS
// ==================================================

function slugify(value) {
  return value.toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
}

function clean(value) {
  return typeof value === "string" ? value.trim() : "";
}

function validTime(value) {
  return typeof value === "string" &&
    /^([01]\d|2[0-3]):[0-5]\d$/.test(value);
}

function validDate(value) {
  if (typeof value !== "string" ||
      !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    return false;
  }

  const parsed = new Date(`${value}T00:00:00Z`);

  return !Number.isNaN(parsed.getTime()) &&
    parsed.toISOString().slice(0, 10) === value;
}

function isPastAppointment(date, time) {
  return new Date(`${date}T${time}:00`).getTime() <= Date.now();
}

function getDay(date) {
  return new Date(`${date}T12:00:00Z`)
    .toLocaleDateString("en-US", {
      weekday: "long",
      timeZone: "UTC"
    });
}

function handleError(res, error, message) {
  console.error("Server error:", error);

  if (error.code === "SQLITE_CONSTRAINT_UNIQUE") {
    return res.status(409).json({
      error: "This email or username is already registered."
    });
  }

  if (error.code === "SQLITE_CONSTRAINT_FOREIGNKEY") {
    return res.status(400).json({
      error: "Invalid patient or doctor account."
    });
  }

  return res.status(500).json({ error: message });
}

function regenerateSession(req, res, userType, userId, redirect) {
  req.session.regenerate(error => {
    if (error) {
      console.error("Session error:", error);
      return res.status(500).json({
        error: "Could not create session."
      });
    }

    req.session[userType] = userId;

    req.session.save(saveError => {
      if (saveError) {
        console.error("Session save error:", saveError);
        return res.status(500).json({
          error: "Could not save session."
        });
      }

      res.json({
        message: "Login successful.",
        redirect
      });
    });
  });
}

// ==================================================
// 5. SEED DOCTORS
// ==================================================

async function seedDoctors() {
  const defaultPassword =
    process.env.DOCTOR_PASSWORD || "DoctorDemo123!";

  const passwordHash = await bcrypt.hash(defaultPassword, 10);

  const insert = db.prepare(`
    INSERT OR IGNORE INTO doctors (
      name, username, password_hash, specialty,
      working_days, start_time, end_time
    )
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);

  db.transaction(() => {
    for (const category of CATEGORIES) {
      const prefix = slugify(category);

      for (let i = 1; i <= 5; i++) {
        insert.run(
          `Dr. ${category} ${i}`,
          `${prefix}_${i}`,
          passwordHash,
          category,
          "Monday,Tuesday,Wednesday,Thursday,Friday",
          "09:00",
          "17:00"
        );
      }
    }
  })();

  console.log(`Standard doctors available: ${CATEGORIES.length * 5}`);
}

// ==================================================
// 6. SEED ADMIN
// ==================================================

async function seedAdmin() {
  const username = clean(process.env.ADMIN_USERNAME);
  const password = process.env.ADMIN_PASSWORD;

  if (!username || !password) {
    console.warn(
      "Admin not seeded: set ADMIN_USERNAME and ADMIN_PASSWORD in .env"
    );
    return;
  }

  if (password.length < 10) {
    throw new Error("ADMIN_PASSWORD must be at least 10 characters.");
  }

  const existing = db.prepare(
    "SELECT id FROM admins WHERE username = ?"
  ).get(username);

  if (existing) {
    console.log("Existing admin account preserved.");
    return;
  }

  const hash = await bcrypt.hash(password, 12);

  db.prepare(`
    INSERT INTO admins (username, password_hash)
    VALUES (?, ?)
  `).run(username, hash);

  console.log("Admin account created.");
}

// ==================================================
// 7. AUTHENTICATION MIDDLEWARE
// ==================================================

function requirePatient(req, res, next) {
  if (!req.session.patientId) {
    return res.status(401).json({
      error: "Please log in as a patient."
    });
  }
  next();
}

function requireDoctor(req, res, next) {
  if (!req.session.doctorId) {
    return res.status(401).json({
      error: "Please log in as a doctor."
    });
  }
  next();
}

function requireAdmin(req, res, next) {
  if (!req.session.adminId) {
    return res.status(401).json({
      error: "Please log in as an admin."
    });
  }
  next();
}

// ==================================================
// 8. PROTECTED ADMIN PAGE AND STATIC FILES
// ==================================================

app.get("/admin-dashboard.html", (req, res) => {
  if (!req.session.adminId) {
    return res.redirect("/admin-login.html");
  }

  res.sendFile(
    path.join(__dirname, "public", "admin-dashboard.html")
  );
});

app.use(express.static(path.join(__dirname, "public")));

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// ==================================================
// 9. CATEGORIES AND DOCTORS
// ==================================================

app.get("/api/categories", (req, res) => {
  res.json(CATEGORIES);
});

app.get("/api/doctors", (req, res) => {
  const specialty = clean(req.query.specialty);

  if (!CATEGORIES.includes(specialty)) {
    return res.status(400).json({
      error: "Select a valid treatment category."
    });
  }

  const prefix = slugify(specialty);

  const doctors = db.prepare(`
    SELECT id, name, specialty, working_days, start_time, end_time
    FROM doctors
    WHERE specialty = ? AND username GLOB ?
    ORDER BY username
    LIMIT 5
  `).all(specialty, `${prefix}_[1-5]`);

  res.json(doctors);
});

// ==================================================
// 10. PATIENT REGISTRATION
// ==================================================

app.post("/api/patient/register", async (req, res) => {
  try {
    const name = clean(req.body.name || req.body.fullName);
    const email = clean(req.body.email).toLowerCase();
    const phone = clean(req.body.phone || req.body.phoneNumber);
    const password = clean(req.body.password);

    if (!name || !email || !password) {
      return res.status(400).json({
        error: "Name, email and password are required."
      });
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({
        error: "Enter a valid email address."
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        error: "Password must contain at least 6 characters."
      });
    }

    const hash = await bcrypt.hash(password, 10);

    const result = db.prepare(`
      INSERT INTO patients (name, email, phone, password_hash)
      VALUES (?, ?, ?, ?)
    `).run(name, email, phone, hash);

    req.session.regenerate(error => {
      if (error) {
        console.error(error);
        return res.status(500).json({
          error: "Could not create session."
        });
      }

      req.session.patientId = Number(result.lastInsertRowid);

      req.session.save(saveError => {
        if (saveError) {
          console.error(saveError);
          return res.status(500).json({
            error: "Could not save session."
          });
        }

        res.status(201).json({
          message: "Patient account created successfully.",
          redirect: "/patient-dashboard.html"
        });
      });
    });
  } catch (error) {
    handleError(res, error, "Could not create patient account.");
  }
});

// ==================================================
// 11. PATIENT LOGIN
// ==================================================

app.post("/api/patient/login", async (req, res) => {
  try {
    const email = clean(req.body.email).toLowerCase();
    const password = clean(req.body.password);

    if (!email || !password) {
      return res.status(400).json({
        error: "Enter your email and password."
      });
    }

    const patient = db.prepare(
      "SELECT * FROM patients WHERE email = ?"
    ).get(email);

    if (
      !patient ||
      !patient.password_hash ||
      !(await bcrypt.compare(password, patient.password_hash))
    ) {
      return res.status(401).json({
        error: "Incorrect email or password."
      });
    }

    regenerateSession(
      req, res, "patientId", patient.id,
      "/patient-dashboard.html"
    );
  } catch (error) {
    handleError(res, error, "Could not log in.");
  }
});

// ==================================================
// 12. PATIENT PROFILE
// ==================================================

app.get("/api/patient/me", requirePatient, (req, res) => {
  const patient = db.prepare(`
    SELECT id, name, email, phone
    FROM patients
    WHERE id = ?
  `).get(req.session.patientId);

  if (!patient) {
    return res.status(404).json({
      error: "Patient account not found."
    });
  }

  res.json(patient);
});

// ==================================================
// 13. BOOK APPOINTMENT
// ==================================================

const bookAppointment = db.transaction(
  (patientId, doctorId, date, time, reason) => {
    const occupied = db.prepare(`
      SELECT id FROM appointments
      WHERE doctor_id = ?
        AND appointment_date = ?
        AND time = ?
        AND status IN ('Pending', 'Confirmed')
    `).get(doctorId, date, time);

    if (occupied) {
      return { conflict: true };
    }

    const result = db.prepare(`
      INSERT INTO appointments (
        patient_id, doctor_id, appointment_date,
        time, reason, status
      )
      VALUES (?, ?, ?, ?, ?, 'Pending')
    `).run(patientId, doctorId, date, time, reason);

    return {
      conflict: false,
      appointmentId: Number(result.lastInsertRowid)
    };
  }
);

app.post("/api/appointments", requirePatient, (req, res) => {
  try {
    const doctorId = Number(req.body.doctorId);
    const date = clean(req.body.date);
    const time = clean(req.body.time);
    const reason = clean(req.body.reason);

    if (
      !Number.isInteger(doctorId) ||
      doctorId <= 0 ||
      !validDate(date) ||
      !validTime(time) ||
      !reason
    ) {
      return res.status(400).json({
        error: "Please enter valid appointment details."
      });
    }

    if (isPastAppointment(date, time)) {
      return res.status(400).json({
        error: "Please choose a future appointment date and time."
      });
    }

    const doctor = db.prepare(
      "SELECT * FROM doctors WHERE id = ?"
    ).get(doctorId);

    if (!doctor) {
      return res.status(404).json({
        error: "Doctor not found."
      });
    }

    const day = getDay(date);
    const workingDays = (doctor.working_days || "")
      .split(",")
      .map(x => x.trim());

    if (!workingDays.includes(day)) {
      return res.status(400).json({
        error: `This doctor does not work on ${day}.`
      });
    }

    if (time < doctor.start_time || time >= doctor.end_time) {
      return res.status(400).json({
        error: `Choose a time between ${doctor.start_time} and ${doctor.end_time}.`
      });
    }

    const result = bookAppointment(
      req.session.patientId,
      doctorId,
      date,
      time,
      reason
    );

    if (result.conflict) {
      return res.status(409).json({
        error: "This time slot is already requested. Choose another time."
      });
    }

    res.status(201).json({
      message: "Appointment request submitted successfully!",
      appointmentId: result.appointmentId
    });
  } catch (error) {
    handleError(res, error, "Could not book the appointment.");
  }
});

// ==================================================
// 14. PATIENT APPOINTMENTS
// ==================================================

app.get("/api/patient/appointments", requirePatient, (req, res) => {
  try {
    const rows = db.prepare(`
      SELECT
        a.id,
        a.appointment_date AS date,
        a.time,
        a.reason,
        a.status,
        d.name AS doctor_name,
        d.specialty
      FROM appointments a
      JOIN doctors d ON d.id = a.doctor_id
      WHERE a.patient_id = ?
      ORDER BY a.appointment_date DESC, a.time DESC
    `).all(req.session.patientId);

    res.json(rows);
  } catch (error) {
    handleError(res, error, "Could not load appointments.");
  }
});

// ==================================================
// 15. DOCTOR LOGIN
// ==================================================

app.post("/api/doctor/login", async (req, res) => {
  try {
    const username = clean(req.body.username);
    const password = clean(req.body.password);

    if (!username || !password) {
      return res.status(400).json({
        error: "Enter your doctor username and password."
      });
    }

    const doctor = db.prepare(
      "SELECT * FROM doctors WHERE username = ?"
    ).get(username);

    if (
      !doctor ||
      !doctor.password_hash ||
      !(await bcrypt.compare(password, doctor.password_hash))
    ) {
      return res.status(401).json({
        error: "Incorrect doctor username or password."
      });
    }

    regenerateSession(
      req, res, "doctorId", doctor.id,
      "/doctor-dashboard.html"
    );
  } catch (error) {
    handleError(res, error, "Could not log in as doctor.");
  }
});

// ==================================================
// 16. DOCTOR PROFILE
// ==================================================

app.get("/api/doctor/me", requireDoctor, (req, res) => {
  const doctor = db.prepare(`
    SELECT
      id, name, username, specialty,
      working_days, start_time, end_time
    FROM doctors
    WHERE id = ?
  `).get(req.session.doctorId);

  if (!doctor) {
    return res.status(404).json({
      error: "Doctor account not found."
    });
  }

  res.json(doctor);
});

// ==================================================
// 17. DOCTOR APPOINTMENTS
// ==================================================

app.get("/api/doctor/appointments", requireDoctor, (req, res) => {
  try {
    const rows = db.prepare(`
      SELECT
        a.id,
        a.appointment_date AS date,
        a.time,
        a.reason,
        a.status,
        p.name AS patient_name,
        p.email AS patient_email,
        p.phone AS patient_phone
      FROM appointments a
      JOIN patients p ON p.id = a.patient_id
      WHERE a.doctor_id = ?
      ORDER BY a.appointment_date DESC, a.time DESC
    `).all(req.session.doctorId);

    res.json(rows);
  } catch (error) {
    handleError(res, error, "Could not load doctor appointments.");
  }
});

// ==================================================
// 18. DOCTOR SCHEDULE
// ==================================================

app.put("/api/doctor/schedule", requireDoctor, (req, res) => {
  const workingDays = req.body.workingDays;
  const startTime = clean(req.body.startTime);
  const endTime = clean(req.body.endTime);

  if (
    !Array.isArray(workingDays) ||
    !workingDays.length ||
    !workingDays.every(day => DAYS.includes(day)) ||
    new Set(workingDays).size !== workingDays.length ||
    !validTime(startTime) ||
    !validTime(endTime) ||
    startTime >= endTime
  ) {
    return res.status(400).json({
      error: "Please choose valid working days and times."
    });
  }

  db.prepare(`
    UPDATE doctors
    SET working_days = ?, start_time = ?, end_time = ?
    WHERE id = ?
  `).run(
    workingDays.join(","),
    startTime,
    endTime,
    req.session.doctorId
  );

  res.json({
    message: "Doctor schedule updated successfully."
  });
});

// ==================================================
// 19. DOCTOR UPDATES APPOINTMENT STATUS
// ==================================================

const updateDoctorAppointment = db.transaction(
  (id, doctorId, status) => {
    const appointment = db.prepare(`
      SELECT *
      FROM appointments
      WHERE id = ? AND doctor_id = ?
    `).get(id, doctorId);

    if (!appointment) {
      return { error: "Appointment not found.", code: 404 };
    }

    if (
      ["Confirmed", "Rejected"].includes(status) &&
      appointment.status !== "Pending"
    ) {
      return {
        error: "Only pending appointments can be confirmed or rejected.",
        code: 400
      };
    }

    if (
      status === "Completed" &&
      appointment.status !== "Confirmed"
    ) {
      return {
        error: "Only confirmed appointments can be completed.",
        code: 400
      };
    }

    if (status === "Confirmed") {
      const conflict = db.prepare(`
        SELECT id
        FROM appointments
        WHERE doctor_id = ?
          AND appointment_date = ?
          AND time = ?
          AND id != ?
          AND status = 'Confirmed'
      `).get(
        doctorId,
        appointment.appointment_date,
        appointment.time,
        id
      );

      if (conflict) {
        return {
          error: "Another appointment is confirmed for this time.",
          code: 409
        };
      }
    }

    db.prepare(`
      UPDATE appointments
      SET status = ?
      WHERE id = ? AND doctor_id = ?
    `).run(status, id, doctorId);

    return { success: true };
  }
);

app.patch("/api/appointments/:id/status", requireDoctor, (req, res) => {
  try {
    const id = Number(req.params.id);
    const status = clean(req.body.status);

    if (
      !Number.isInteger(id) ||
      id <= 0 ||
      !["Confirmed", "Rejected", "Completed"].includes(status)
    ) {
      return res.status(400).json({
        error: "Invalid appointment ID or status."
      });
    }

    const result = updateDoctorAppointment(
      id,
      req.session.doctorId,
      status
    );

    if (result.error) {
      return res.status(result.code).json({
        error: result.error
      });
    }

    res.json({
      message: `Appointment ${status.toLowerCase()} successfully.`
    });
  } catch (error) {
    handleError(res, error, "Could not update appointment status.");
  }
});

// ==================================================
// 20. ADMIN LOGIN
// ==================================================

app.post("/api/admin/login", async (req, res) => {
  try {
    const username = clean(req.body.username);
    const password = clean(req.body.password);

    if (!username || !password) {
      return res.status(400).json({
        error: "Enter admin username and password."
      });
    }

    const admin = db.prepare(
      "SELECT * FROM admins WHERE username = ?"
    ).get(username);

    if (
      !admin ||
      !(await bcrypt.compare(password, admin.password_hash))
    ) {
      return res.status(401).json({
        error: "Incorrect admin username or password."
      });
    }

    regenerateSession(
      req, res, "adminId", admin.id,
      "/admin-dashboard.html"
    );
  } catch (error) {
    handleError(res, error, "Admin login failed.");
  }
});

// ==================================================
// 21. ADMIN PROFILE
// ==================================================

app.get("/api/admin/me", requireAdmin, (req, res) => {
  const admin = db.prepare(`
    SELECT id, username
    FROM admins
    WHERE id = ?
  `).get(req.session.adminId);

  if (!admin) {
    return res.status(404).json({
      error: "Admin account not found."
    });
  }

  res.json(admin);
});

// ==================================================
// 22. ADMIN DASHBOARD STATISTICS
// ==================================================

app.get("/api/admin/overview", requireAdmin, (req, res) => {
  const patients = db.prepare(
    "SELECT COUNT(*) AS total FROM patients"
  ).get().total;

  const doctors = db.prepare(
    "SELECT COUNT(*) AS total FROM doctors"
  ).get().total;

  const appointments = db.prepare(
    "SELECT COUNT(*) AS total FROM appointments"
  ).get().total;

  const pending = db.prepare(`
    SELECT COUNT(*) AS total
    FROM appointments
    WHERE status = 'Pending'
  `).get().total;

  res.json({
    patients,
    doctors,
    appointments,
    pending
  });
});

// ==================================================
// 23. ADMIN VIEW PATIENTS
// ==================================================

app.get("/api/admin/patients", requireAdmin, (req, res) => {
  const patients = db.prepare(`
    SELECT id, name, email, phone, created_at
    FROM patients
    ORDER BY id DESC
  `).all();

  res.json(patients);
});

// ==================================================
// 24. ADMIN VIEW DOCTORS
// ==================================================

app.get("/api/admin/doctors", requireAdmin, (req, res) => {
  const doctors = db.prepare(`
    SELECT
      id, name, username, specialty,
      working_days, start_time, end_time
    FROM doctors
    ORDER BY specialty, name
  `).all();

  res.json(doctors);
});

// ==================================================
// 25. ADMIN VIEW ALL APPOINTMENTS
// ==================================================

app.get("/api/admin/appointments", requireAdmin, (req, res) => {
  const appointments = db.prepare(`
    SELECT
      a.id,
      a.appointment_date AS date,
      a.time,
      a.reason,
      a.status,
      p.name AS patient_name,
      p.email AS patient_email,
      d.name AS doctor_name,
      d.specialty
    FROM appointments a
    JOIN patients p ON p.id = a.patient_id
    JOIN doctors d ON d.id = a.doctor_id
    ORDER BY a.appointment_date DESC, a.time DESC
  `).all();

  res.json(appointments);
});

// ==================================================
// 26. ADMIN UPDATE APPOINTMENT STATUS
// ==================================================

const updateAdminAppointment = db.transaction((id, status) => {
  const appointment = db.prepare(`
    SELECT *
    FROM appointments
    WHERE id = ?
  `).get(id);

  if (!appointment) {
    return { error: "Appointment not found.", code: 404 };
  }

  if (status === "Confirmed") {
    const conflict = db.prepare(`
      SELECT id
      FROM appointments
      WHERE doctor_id = ?
        AND appointment_date = ?
        AND time = ?
        AND id != ?
        AND status = 'Confirmed'
    `).get(
      appointment.doctor_id,
      appointment.appointment_date,
      appointment.time,
      id
    );

    if (conflict) {
      return {
        error: "Another appointment is already confirmed for this time.",
        code: 409
      };
    }
  }

  db.prepare(`
    UPDATE appointments
    SET status = ?
    WHERE id = ?
  `).run(status, id);

  return { success: true };
});

app.patch(
  "/api/admin/appointments/:id/status",
  requireAdmin,
  (req, res) => {
    try {
      const id = Number(req.params.id);
      const status = clean(req.body.status);

      const allowed = [
        "Pending",
        "Confirmed",
        "Rejected",
        "Completed"
      ];

      if (
        !Number.isInteger(id) ||
        id <= 0 ||
        !allowed.includes(status)
      ) {
        return res.status(400).json({
          error: "Invalid appointment ID or status."
        });
      }

      const result = updateAdminAppointment(id, status);

      if (result.error) {
        return res.status(result.code).json({
          error: result.error
        });
      }

      res.json({
        message: "Appointment status updated."
      });
    } catch (error) {
      handleError(res, error, "Could not update appointment status.");
    }
  }
);

// ==================================================
// 27. LOGOUT
// ==================================================

app.post("/api/logout", (req, res) => {
  req.session.destroy(error => {
    if (error) {
      console.error("Logout error:", error);
      return res.status(500).json({
        error: "Could not log out."
      });
    }

    res.clearCookie("carepoint.sid");

    res.json({
      message: "Logged out successfully.",
      redirect: "/"
    });
  });
});

// ==================================================
// 28. UNKNOWN API ROUTES
// ==================================================

app.use("/api", (req, res) => {
  res.status(404).json({
    error: "API endpoint not found."
  });
});

// ==================================================
// 29. SERVER ERROR HANDLER
// ==================================================

app.use((error, req, res, next) => {
  console.error("Unexpected server error:", error);

  if (res.headersSent) {
    return next(error);
  }

  res.status(500).json({
    error: "An unexpected server error occurred."
  });
});

// ==================================================
// 30. START SERVER
// ==================================================

async function startServer() {
  try {
    await seedDoctors();
    await seedAdmin();

    app.listen(PORT, () => {
      console.log("------------------------------------");
      console.log("       CAREPOINT SERVER STARTED");
      console.log("------------------------------------");
      console.log(`Website: http://localhost:${PORT}`);
      console.log(`Categories: ${CATEGORIES.length}`);
      console.log(`Standard doctors: ${CATEGORIES.length * 5}`);
      console.log("------------------------------------");
    });
  } catch (error) {
    console.error("Server startup failed:", error);
    process.exit(1);
  }
}

startServer();